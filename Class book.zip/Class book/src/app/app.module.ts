import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule} from '@angular/forms'
import { AppComponent } from './app.component';

import {Routes,RouterModule} from '@angular/router';
import { AddComponent } from './app.adcomponent';
import { SearchComponent } from './app.searchcomponent';
import { HttpClientModule } from '../../node_modules/@angular/common/http';

const routes:Routes=[
  {path:'getadd',component:AddComponent},
  {path:'getsearch',component:SearchComponent}
];
@NgModule({
  declarations: [
    AppComponent,AddComponent,SearchComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(routes),HttpClientModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
