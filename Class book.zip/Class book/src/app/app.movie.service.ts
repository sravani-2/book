import { Injectable } from "@angular/core";
import{HttpClient} from '@angular/common/http'

@Injectable()
export class MovieService{

constructor(private http:HttpClient){}

    getAddMovies(data:any):any{
        return this.http.post("http://localhost:3456/addmovie",data)
    }

    getSearchMovies(data:any):any{
        return this.http.get("http://localhost:3456/searchmovie/"+data)
    }

}