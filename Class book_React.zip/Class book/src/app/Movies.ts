export class Movies{
    name:String
    rating:Number
    genre:String
}