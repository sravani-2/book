import { Component } from '@angular/core';
import { MovieService } from './app.movie.service';
import { Movies } from './Movies';

@Component({
  selector: 'ser-comp',
 templateUrl:'./app.search.html',
 providers:[MovieService]
})
export class SearchComponent {
    genre:string
    msg:boolean=false
    movies:Movies[]
    constructor(private movieservice:MovieService){}

    searchmovies(){
        this.movieservice.getSearchMovies(this.genre).subscribe((data:Movies[])=>this.movies=data)
        this.msg=true
        this.genre=""
    }
}



