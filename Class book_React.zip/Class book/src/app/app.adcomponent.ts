import { Component } from '@angular/core';
import { MovieService } from './app.movie.service';
import {Router} from '@angular/router';
@Component({
    selector: 'add-comp',
    templateUrl:'./app.addmovies.html',
    providers:[MovieService]
})
export class AddComponent {
    model:any={

    }
    constructor(private movieservice:MovieService,private router: Router){}
    addmovies(){
        this.movieservice.getAddMovies(this.model).subscribe()
        this.model={}
        // this.router.navigate(['']);
    }
}
